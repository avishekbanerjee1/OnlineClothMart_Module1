package com.virtusa.OnlineClothMart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineClothMartApplicationTests {

	@Test
	void contextLoads() {
	}

}
