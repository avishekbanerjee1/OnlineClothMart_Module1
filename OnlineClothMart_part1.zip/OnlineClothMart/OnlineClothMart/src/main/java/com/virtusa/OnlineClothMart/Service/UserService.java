package com.virtusa.OnlineClothMart.Service;

import com.virtusa.OnlineClothMart.Model.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}