package com.virtusa.OnlineClothMart.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.OnlineClothMart.Model.Role;


public interface RoleRepository extends JpaRepository<Role, Long>{
}