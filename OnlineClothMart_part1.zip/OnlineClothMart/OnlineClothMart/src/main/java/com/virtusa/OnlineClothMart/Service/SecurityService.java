package com.virtusa.OnlineClothMart.Service;

public interface SecurityService {
    String findLoggedInUsername();

    void autoLogin(String username, String password);
}